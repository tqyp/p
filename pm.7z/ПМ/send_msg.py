import socket
address,message=('127.0.0.1',20001),'the ultimate message!'#адрес получателя и сообщение
udps=socket.socket(family=socket.AF_INET,type=socket.SOCK_DGRAM)#создание udp
udps.sendto(str.encode(message),address)#отправка сообщения
