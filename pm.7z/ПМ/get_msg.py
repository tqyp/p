import socket
udps=socket.socket(family=socket.AF_INET,type=socket.SOCK_DGRAM)#создание udp
udps.bind(('127.0.0.1',20001)) #старт получения сообщений
while True: print(udps.recvfrom(1024)[0].decode('utf-8')) #бесконечный прием сообщений


