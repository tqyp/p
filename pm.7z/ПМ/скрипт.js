function showMessage() {
    var msg = ''; 
    for (var i = 1; i < 11; i++){
        msg = "Это " + i + " строка" + "<br>";
         document.write(msg);
    }

}