import socket
def ison(ip,port):
   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   try:
      s.connect((ip,port))
      s.shutdown(2)
      return True
   except:
      return False

fr,to=int(input('from: ')),int(input('to: '))
for i in range(fr,to): print(i,':',ison('127.0.0.1',i))
